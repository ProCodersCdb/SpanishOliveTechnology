package es.procoders.spanisholivetechnology.services;

/**
 * @author Procoders
 * @version 1.0
 * @since API 21
 */

//Interfaz que declara el funcionamiento genérico de una regla de negocio
public interface BussinessRule {

    /**
     *
     */
}
