package es.procoders.spanisholivetechnology.beans;

/**
 * Created by bjfem on 10/11/2017.
 */

public enum TipoRespuesta {
    ALMAZARA, BIOMASA, COMERCIOACEITUNA, COMERCIOACEITE, FABRICAACEITUNA;
}
